package com.quiz.dao;

import com.quiz.database.DatabaseManager;
import com.quiz.model.Quiz;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Quiz operations
 */
public class QuizDAO {
    
    /**
     * Create a new quiz
     */
    public boolean createQuiz(Quiz quiz) {
        String sql = "INSERT INTO quizzes (title, description, created_by, created_at) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, quiz.getTitle());
            pstmt.setString(2, quiz.getDescription());
            pstmt.setInt(3, quiz.getCreatedBy());
            pstmt.setTimestamp(4, Timestamp.valueOf(quiz.getCreatedAt()));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        quiz.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error creating quiz: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Get all quizzes
     */
    public List<Quiz> getAllQuizzes() {
        List<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT * FROM quizzes ORDER BY created_at DESC";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Quiz quiz = new Quiz(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("description"),
                    rs.getInt("created_by"),
                    rs.getTimestamp("created_at").toLocalDateTime()
                );
                quizzes.add(quiz);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all quizzes: " + e.getMessage());
        }
        
        return quizzes;
    }
    
    /**
     * Find quiz by ID
     */
    public Quiz findById(int id) {
        String sql = "SELECT * FROM quizzes WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Quiz(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getInt("created_by"),
                        rs.getTimestamp("created_at").toLocalDateTime()
                    );
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error finding quiz: " + e.getMessage());
        }
        
        return null;
    }
    
    /**
     * Update quiz
     */
    public boolean updateQuiz(Quiz quiz) {
        String sql = "UPDATE quizzes SET title = ?, description = ? WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, quiz.getTitle());
            pstmt.setString(2, quiz.getDescription());
            pstmt.setInt(3, quiz.getId());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating quiz: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Delete quiz
     */
    public boolean deleteQuiz(int quizId) {
        String sql = "DELETE FROM quizzes WHERE id = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting quiz: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Get quiz count
     */
    public int getQuizCount() {
        String sql = "SELECT COUNT(*) FROM quizzes";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting quiz count: " + e.getMessage());
        }
        
        return 0;
    }
}
