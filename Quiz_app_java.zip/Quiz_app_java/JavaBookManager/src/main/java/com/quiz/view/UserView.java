package com.quiz.view;

import com.quiz.QuizApplication;
import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.QuizResult;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

import java.time.format.DateTimeFormatter;

/**
 * User dashboard view for taking quizzes and viewing results
 */
public class UserView {
    private BorderPane mainContainer;
    private User currentUser;
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private TableView<Quiz> quizTable;
    private TableView<QuizResult> resultsTable;
    private ObservableList<Quiz> quizList;
    private ObservableList<QuizResult> resultsList;
    private TabPane tabPane;
    
    public UserView(User user) {
        this.currentUser = user;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
        this.quizList = FXCollections.observableArrayList();
        this.resultsList = FXCollections.observableArrayList();
        createView();
        loadData();
    }
    
    private void createView() {
        mainContainer = new BorderPane();
        mainContainer.getStyleClass().add("main-container");
        
        // Top toolbar
        HBox toolbar = createToolbar();
        mainContainer.setTop(toolbar);
        
        // Center content with tabs
        tabPane = new TabPane();
        
        // Available Quizzes tab
        Tab quizzesTab = new Tab("Available Quizzes");
        quizzesTab.setClosable(false);
        quizzesTab.setContent(createQuizzesTab());
        
        // My Results tab
        Tab resultsTab = new Tab("My Results");
        resultsTab.setClosable(false);
        resultsTab.setContent(createResultsTab());
        
        tabPane.getTabs().addAll(quizzesTab, resultsTab);
        
        mainContainer.setCenter(tabPane);
    }
    
    private HBox createToolbar() {
        HBox toolbar = new HBox(20);
        toolbar.setPadding(new Insets(15));
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.getStyleClass().add("toolbar");
        
        Label titleLabel = new Label("Quiz Dashboard - Welcome, " + currentUser.getUsername());
        titleLabel.getStyleClass().add("toolbar-title");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("secondary-button");
        logoutButton.setOnAction(e -> logout());
        
        toolbar.getChildren().addAll(titleLabel, spacer, logoutButton);
        return toolbar;
    }
    
    private VBox createQuizzesTab() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        
        Label titleLabel = new Label("Available Quizzes");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        
        // Quiz table
        createQuizTable();
        
        // Action buttons
        HBox actions = new HBox(10);
        actions.setAlignment(Pos.CENTER_LEFT);
        
        Button takeQuizButton = new Button("Take Quiz");
        takeQuizButton.getStyleClass().add("primary-button");
        takeQuizButton.setOnAction(e -> takeQuiz());
        
        Button refreshButton = new Button("Refresh");
        refreshButton.getStyleClass().add("secondary-button");
        refreshButton.setOnAction(e -> loadQuizzes());
        
        actions.getChildren().addAll(takeQuizButton, refreshButton);
        
        content.getChildren().addAll(titleLabel, quizTable, actions);
        return content;
    }
    
    private VBox createResultsTab() {
        VBox content = new VBox(20);
        content.setPadding(new Insets(20));
        
        Label titleLabel = new Label("My Quiz Results");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        
        // Results table
        createResultsTable();
        
        // Action buttons
        HBox actions = new HBox(10);
        actions.setAlignment(Pos.CENTER_LEFT);
        
        Button refreshButton = new Button("Refresh");
        refreshButton.getStyleClass().add("secondary-button");
        refreshButton.setOnAction(e -> loadResults());
        
        actions.getChildren().add(refreshButton);
        
        content.getChildren().addAll(titleLabel, resultsTable, actions);
        return content;
    }
    
    private void createQuizTable() {
        quizTable = new TableView<>();
        quizTable.setItems(quizList);
        
        TableColumn<Quiz, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleColumn.setPrefWidth(200);
        
        TableColumn<Quiz, String> descColumn = new TableColumn<>("Description");
        descColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        descColumn.setPrefWidth(300);
        
        TableColumn<Quiz, Integer> questionsColumn = new TableColumn<>("Questions");
        questionsColumn.setCellValueFactory(cellData -> {
            int count = questionDAO.getQuestionCount(cellData.getValue().getId());
            return new javafx.beans.property.SimpleIntegerProperty(count).asObject();
        });
        questionsColumn.setPrefWidth(100);
        
        TableColumn<Quiz, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(cellData -> {
            QuizResult bestResult = resultDAO.getBestScore(currentUser.getId(), cellData.getValue().getId());
            if (bestResult != null) {
                return new javafx.beans.property.SimpleStringProperty(
                    String.format("Best: %.1f%%", bestResult.getPercentage())
                );
            } else {
                return new javafx.beans.property.SimpleStringProperty("Not taken");
            }
        });
        statusColumn.setPrefWidth(120);
        
        quizTable.getColumns().addAll(titleColumn, descColumn, questionsColumn, statusColumn);
        quizTable.setPrefHeight(350);
        
        // Double-click to take quiz
        quizTable.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                takeQuiz();
            }
        });
    }
    
    private void createResultsTable() {
        resultsTable = new TableView<>();
        resultsTable.setItems(resultsList);
        
        TableColumn<QuizResult, String> quizColumn = new TableColumn<>("Quiz");
        quizColumn.setCellValueFactory(new PropertyValueFactory<>("quizTitle"));
        quizColumn.setPrefWidth(200);
        
        TableColumn<QuizResult, Integer> scoreColumn = new TableColumn<>("Score");
        scoreColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            return new javafx.beans.property.SimpleIntegerProperty(result.getScore()).asObject();
        });
        scoreColumn.setPrefWidth(80);
        
        TableColumn<QuizResult, Integer> totalColumn = new TableColumn<>("Total");
        totalColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            return new javafx.beans.property.SimpleIntegerProperty(result.getTotalQuestions()).asObject();
        });
        totalColumn.setPrefWidth(80);
        
        TableColumn<QuizResult, String> percentageColumn = new TableColumn<>("Percentage");
        percentageColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                String.format("%.1f%%", result.getPercentage())
            );
        });
        percentageColumn.setPrefWidth(100);
        
        TableColumn<QuizResult, String> dateColumn = new TableColumn<>("Date Taken");
        dateColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
            return new javafx.beans.property.SimpleStringProperty(
                result.getTakenAt().format(formatter)
            );
        });
        dateColumn.setPrefWidth(150);
        
        resultsTable.getColumns().addAll(quizColumn, scoreColumn, totalColumn, percentageColumn, dateColumn);
        resultsTable.setPrefHeight(350);
    }
    
    private void loadData() {
        loadQuizzes();
        loadResults();
    }
    
    private void loadQuizzes() {
        quizList.clear();
        quizList.addAll(quizDAO.getAllQuizzes());
    }
    
    private void loadResults() {
        resultsList.clear();
        resultsList.addAll(resultDAO.getResultsByUserId(currentUser.getId()));
    }
    
    private void takeQuiz() {
        Quiz selectedQuiz = quizTable.getSelectionModel().getSelectedItem();
        if (selectedQuiz == null) {
            AlertUtil.showWarning("No Selection", "Please select a quiz to take.");
            return;
        }
        
        int questionCount = questionDAO.getQuestionCount(selectedQuiz.getId());
        if (questionCount == 0) {
            AlertUtil.showWarning("No Questions", "This quiz has no questions available.");
            return;
        }
        
        QuizView quizView = new QuizView(selectedQuiz, currentUser, this::refreshAfterQuiz);
        quizView.show();
    }
    
    private void refreshAfterQuiz() {
        loadResults();
        quizTable.refresh(); // Refresh to update status column
        tabPane.getSelectionModel().select(1); // Switch to results tab
    }
    
    private void logout() {
        QuizApplication.showLoginView();
    }
    
    public BorderPane getView() {
        return mainContainer;
    }
}
