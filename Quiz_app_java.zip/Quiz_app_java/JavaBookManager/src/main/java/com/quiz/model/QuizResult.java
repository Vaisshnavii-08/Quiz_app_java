package com.quiz.model;

import java.time.LocalDateTime;

/**
 * QuizResult model class representing a user's quiz attempt result
 */
public class QuizResult {
    private int id;
    private int userId;
    private int quizId;
    private int score;
    private int totalQuestions;
    private LocalDateTime takenAt;
    private String quizTitle; // For display purposes
    
    public QuizResult() {}
    
    public QuizResult(int userId, int quizId, int score, int totalQuestions) {
        this.userId = userId;
        this.quizId = quizId;
        this.score = score;
        this.totalQuestions = totalQuestions;
        this.takenAt = LocalDateTime.now();
    }
    
    public QuizResult(int id, int userId, int quizId, int score, int totalQuestions, LocalDateTime takenAt) {
        this.id = id;
        this.userId = userId;
        this.quizId = quizId;
        this.score = score;
        this.totalQuestions = totalQuestions;
        this.takenAt = takenAt;
    }
    
    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getQuizId() { return quizId; }
    public void setQuizId(int quizId) { this.quizId = quizId; }
    
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    
    public int getTotalQuestions() { return totalQuestions; }
    public void setTotalQuestions(int totalQuestions) { this.totalQuestions = totalQuestions; }
    
    public LocalDateTime getTakenAt() { return takenAt; }
    public void setTakenAt(LocalDateTime takenAt) { this.takenAt = takenAt; }
    
    public String getQuizTitle() { return quizTitle; }
    public void setQuizTitle(String quizTitle) { this.quizTitle = quizTitle; }
    
    public double getPercentage() {
        return totalQuestions > 0 ? (double) score / totalQuestions * 100 : 0;
    }
}
