package com.quiz.view;

import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.QuizResult;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * View for displaying quiz results and statistics
 */
public class ResultsView {
    private Stage stage;
    private Quiz quiz;
    private QuizResultDAO resultDAO;
    private TableView<QuizResult> resultsTable;
    private ObservableList<QuizResult> resultsList;
    private Label statsLabel;
    
    public ResultsView(Quiz quiz) {
        this.quiz = quiz;
        this.resultDAO = new QuizResultDAO();
        this.resultsList = FXCollections.observableArrayList();
        createView();
        loadResults();
    }
    
    private void createView() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Quiz Results: " + quiz.getTitle());
        stage.setMinWidth(800);
        stage.setMinHeight(600);
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        
        // Header
        VBox header = createHeader();
        
        // Statistics
        statsLabel = new Label();
        statsLabel.getStyleClass().add("stats-label");
        
        // Results table
        createResultsTable();
        
        // Close button
        HBox buttonBox = new HBox();
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        
        Button closeButton = new Button("Close");
        closeButton.getStyleClass().add("secondary-button");
        closeButton.setOnAction(e -> stage.close());
        
        buttonBox.getChildren().add(closeButton);
        
        mainContainer.getChildren().addAll(header, statsLabel, resultsTable, buttonBox);
        
        Scene scene = new Scene(new ScrollPane(mainContainer), 800, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
    }
    
    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        
        Label titleLabel = new Label("Quiz Results");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.getStyleClass().add("results-title");
        
        Label quizLabel = new Label(quiz.getTitle());
        quizLabel.setFont(Font.font("Arial", FontWeight.NORMAL, 18));
        quizLabel.getStyleClass().add("results-quiz-title");
        
        if (quiz.getDescription() != null && !quiz.getDescription().trim().isEmpty()) {
            Label descLabel = new Label(quiz.getDescription());
            descLabel.setWrapText(true);
            descLabel.getStyleClass().add("results-description");
            header.getChildren().addAll(titleLabel, quizLabel, descLabel);
        } else {
            header.getChildren().addAll(titleLabel, quizLabel);
        }
        
        return header;
    }
    
    private void createResultsTable() {
        resultsTable = new TableView<>();
        resultsTable.setItems(resultsList);
        
        // User column (for admin view)
        TableColumn<QuizResult, String> userColumn = new TableColumn<>("User");
        userColumn.setCellValueFactory(cellData -> {
            // You might want to add username to QuizResult or join with users table
            return new javafx.beans.property.SimpleStringProperty("User " + cellData.getValue().getUserId());
        });
        userColumn.setPrefWidth(100);
        
        // Score column
        TableColumn<QuizResult, String> scoreColumn = new TableColumn<>("Score");
        scoreColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                result.getScore() + "/" + result.getTotalQuestions()
            );
        });
        scoreColumn.setPrefWidth(80);
        
        // Percentage column
        TableColumn<QuizResult, String> percentageColumn = new TableColumn<>("Percentage");
        percentageColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                String.format("%.1f%%", result.getPercentage())
            );
        });
        percentageColumn.setPrefWidth(100);
        
        // Grade column
        TableColumn<QuizResult, String> gradeColumn = new TableColumn<>("Grade");
        gradeColumn.setCellValueFactory(cellData -> {
            double percentage = cellData.getValue().getPercentage();
            String grade = getGrade(percentage);
            return new javafx.beans.property.SimpleStringProperty(grade);
        });
        gradeColumn.setPrefWidth(80);
        
        // Date taken column
        TableColumn<QuizResult, String> dateColumn = new TableColumn<>("Date Taken");
        dateColumn.setCellValueFactory(cellData -> {
            QuizResult result = cellData.getValue();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
            return new javafx.beans.property.SimpleStringProperty(
                result.getTakenAt().format(formatter)
            );
        });
        dateColumn.setPrefWidth(150);
        
        resultsTable.getColumns().addAll(userColumn, scoreColumn, percentageColumn, gradeColumn, dateColumn);
        resultsTable.setPrefHeight(350);
        
        // Sort by percentage descending by default
        percentageColumn.setSortType(TableColumn.SortType.DESCENDING);
        resultsTable.getSortOrder().add(percentageColumn);
    }
    
    private void loadResults() {
        List<QuizResult> results = resultDAO.getResultsByQuizId(quiz.getId());
        resultsList.clear();
        resultsList.addAll(results);
        
        updateStatistics(results);
    }
    
    private void updateStatistics(List<QuizResult> results) {
        if (results.isEmpty()) {
            statsLabel.setText("No results available for this quiz.");
            return;
        }
        
        int totalAttempts = results.size();
        double totalPercentage = results.stream().mapToDouble(QuizResult::getPercentage).sum();
        double averagePercentage = totalPercentage / totalAttempts;
        double maxPercentage = results.stream().mapToDouble(QuizResult::getPercentage).max().orElse(0);
        double minPercentage = results.stream().mapToDouble(QuizResult::getPercentage).min().orElse(0);
        
        // Count grades
        long excellentCount = results.stream().filter(r -> r.getPercentage() >= 90).count();
        long goodCount = results.stream().filter(r -> r.getPercentage() >= 70 && r.getPercentage() < 90).count();
        long fairCount = results.stream().filter(r -> r.getPercentage() >= 60 && r.getPercentage() < 70).count();
        long poorCount = results.stream().filter(r -> r.getPercentage() < 60).count();
        
        String statsText = String.format(
            "Quiz Statistics:\n" +
            "Total Attempts: %d\n" +
            "Average Score: %.1f%%\n" +
            "Highest Score: %.1f%%\n" +
            "Lowest Score: %.1f%%\n\n" +
            "Grade Distribution:\n" +
            "Excellent (90-100%%): %d\n" +
            "Good (70-89%%): %d\n" +
            "Fair (60-69%%): %d\n" +
            "Poor (< 60%%): %d",
            totalAttempts, averagePercentage, maxPercentage, minPercentage,
            excellentCount, goodCount, fairCount, poorCount
        );
        
        statsLabel.setText(statsText);
    }
    
    private String getGrade(double percentage) {
        if (percentage >= 90) return "A";
        else if (percentage >= 80) return "B";
        else if (percentage >= 70) return "C";
        else if (percentage >= 60) return "D";
        else return "F";
    }
    
    public void show() {
        stage.show();
    }
}
