package com.quiz.view;

import com.quiz.QuizApplication;
import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

/**
 * Admin dashboard view for managing quizzes
 */
public class AdminView {
    private BorderPane mainContainer;
    private User currentUser;
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private TableView<Quiz> quizTable;
    private ObservableList<Quiz> quizList;
    
    public AdminView(User user) {
        this.currentUser = user;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
        this.quizList = FXCollections.observableArrayList();
        createView();
        loadQuizzes();
    }
    
    private void createView() {
        mainContainer = new BorderPane();
        mainContainer.getStyleClass().add("main-container");
        
        // Top toolbar
        HBox toolbar = createToolbar();
        mainContainer.setTop(toolbar);
        
        // Center content
        VBox centerContent = createCenterContent();
        mainContainer.setCenter(centerContent);
    }
    
    private HBox createToolbar() {
        HBox toolbar = new HBox(20);
        toolbar.setPadding(new Insets(15));
        toolbar.setAlignment(Pos.CENTER_LEFT);
        toolbar.getStyleClass().add("toolbar");
        
        Label titleLabel = new Label("Admin Dashboard - Welcome, " + currentUser.getUsername());
        titleLabel.getStyleClass().add("toolbar-title");
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("secondary-button");
        logoutButton.setOnAction(e -> logout());
        
        toolbar.getChildren().addAll(titleLabel, spacer, logoutButton);
        return toolbar;
    }
    
    private VBox createCenterContent() {
        VBox centerContent = new VBox(20);
        centerContent.setPadding(new Insets(20));
        
        // Quiz management section
        Label quizLabel = new Label("Quiz Management");
        quizLabel.getStyleClass().add("section-title");
        
        // Quiz table
        createQuizTable();
        
        // Quiz action buttons
        HBox quizActions = createQuizActions();
        
        centerContent.getChildren().addAll(quizLabel, quizTable, quizActions);
        return centerContent;
    }
    
    private void createQuizTable() {
        quizTable = new TableView<>();
        quizTable.setItems(quizList);
        
        // Title column
        TableColumn<Quiz, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleColumn.setPrefWidth(200);
        
        // Description column
        TableColumn<Quiz, String> descColumn = new TableColumn<>("Description");
        descColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        descColumn.setPrefWidth(300);
        
        // Created date column
        TableColumn<Quiz, String> dateColumn = new TableColumn<>("Created");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("createdAt"));
        dateColumn.setPrefWidth(150);
        
        // Questions count column
        TableColumn<Quiz, Integer> questionsColumn = new TableColumn<>("Questions");
        questionsColumn.setCellValueFactory(cellData -> {
            int count = questionDAO.getQuestionCount(cellData.getValue().getId());
            return new javafx.beans.property.SimpleIntegerProperty(count).asObject();
        });
        questionsColumn.setPrefWidth(100);
        
        quizTable.getColumns().addAll(titleColumn, descColumn, dateColumn, questionsColumn);
        quizTable.setPrefHeight(400);
    }
    
    private HBox createQuizActions() {
        HBox actions = new HBox(10);
        actions.setAlignment(Pos.CENTER_LEFT);
        
        Button createButton = new Button("Create Quiz");
        createButton.getStyleClass().add("primary-button");
        createButton.setOnAction(e -> createQuiz());
        
        Button editButton = new Button("Edit Quiz");
        editButton.getStyleClass().add("secondary-button");
        editButton.setOnAction(e -> editQuiz());
        
        Button deleteButton = new Button("Delete Quiz");
        deleteButton.getStyleClass().add("danger-button");
        deleteButton.setOnAction(e -> deleteQuiz());
        
        Button viewResultsButton = new Button("View Results");
        viewResultsButton.getStyleClass().add("secondary-button");
        viewResultsButton.setOnAction(e -> viewQuizResults());
        
        actions.getChildren().addAll(createButton, editButton, deleteButton, viewResultsButton);
        return actions;
    }
    
    private void loadQuizzes() {
        quizList.clear();
        quizList.addAll(quizDAO.getAllQuizzes());
    }
    
    private void createQuiz() {
        CreateQuizView createQuizView = new CreateQuizView(null, this::loadQuizzes);
        createQuizView.show();
    }
    
    private void editQuiz() {
        Quiz selectedQuiz = quizTable.getSelectionModel().getSelectedItem();
        if (selectedQuiz == null) {
            AlertUtil.showWarning("No Selection", "Please select a quiz to edit.");
            return;
        }
        
        CreateQuizView editQuizView = new CreateQuizView(selectedQuiz, this::loadQuizzes);
        editQuizView.show();
    }
    
    private void deleteQuiz() {
        Quiz selectedQuiz = quizTable.getSelectionModel().getSelectedItem();
        if (selectedQuiz == null) {
            AlertUtil.showWarning("No Selection", "Please select a quiz to delete.");
            return;
        }
        
        boolean confirmed = AlertUtil.showConfirmation(
            "Delete Quiz",
            "Are you sure you want to delete the quiz '" + selectedQuiz.getTitle() + "'?\n" +
            "This will also delete all questions and results associated with this quiz."
        );
        
        if (confirmed) {
            // Delete questions first
            questionDAO.deleteQuestionsByQuizId(selectedQuiz.getId());
            
            // Delete quiz
            if (quizDAO.deleteQuiz(selectedQuiz.getId())) {
                AlertUtil.showSuccess("Success", "Quiz deleted successfully.");
                loadQuizzes();
            } else {
                AlertUtil.showError("Error", "Failed to delete quiz.");
            }
        }
    }
    
    private void viewQuizResults() {
        Quiz selectedQuiz = quizTable.getSelectionModel().getSelectedItem();
        if (selectedQuiz == null) {
            AlertUtil.showWarning("No Selection", "Please select a quiz to view results.");
            return;
        }
        
        ResultsView resultsView = new ResultsView(selectedQuiz);
        resultsView.show();
    }
    
    private void logout() {
        QuizApplication.showLoginView();
    }
    
    public BorderPane getView() {
        return mainContainer;
    }
}
