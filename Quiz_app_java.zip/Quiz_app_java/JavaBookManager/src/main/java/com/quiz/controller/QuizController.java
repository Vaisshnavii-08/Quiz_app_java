package com.quiz.controller;

import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.model.QuizResult;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Controller for handling quiz-taking logic and validation
 */
public class QuizController {
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private User currentUser;
    private Quiz currentQuiz;
    private List<Question> questions;
    private String[] userAnswers;
    private int currentQuestionIndex;
    private boolean quizCompleted;
    
    public QuizController(User currentUser) {
        this.currentUser = currentUser;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
        this.currentQuestionIndex = 0;
        this.quizCompleted = false;
    }
    
    /**
     * Initialize a quiz session
     */
    public boolean initializeQuiz(Quiz quiz) {
        if (quiz == null) {
            AlertUtil.showError("Error", "Invalid quiz selected.");
            return false;
        }
        
        this.currentQuiz = quiz;
        this.questions = questionDAO.getQuestionsByQuizId(quiz.getId());
        
        if (questions.isEmpty()) {
            AlertUtil.showWarning("No Questions", 
                "This quiz has no questions available. Please contact the administrator.");
            return false;
        }
        
        this.userAnswers = new String[questions.size()];
        this.currentQuestionIndex = 0;
        this.quizCompleted = false;
        
        return true;
    }
    
    /**
     * Get current quiz
     */
    public Quiz getCurrentQuiz() {
        return currentQuiz;
    }
    
    /**
     * Get all questions for the current quiz
     */
    public List<Question> getQuestions() {
        return questions != null ? new ArrayList<>(questions) : new ArrayList<>();
    }
    
    /**
     * Get current question
     */
    public Question getCurrentQuestion() {
        if (questions == null || currentQuestionIndex < 0 || currentQuestionIndex >= questions.size()) {
            return null;
        }
        return questions.get(currentQuestionIndex);
    }
    
    /**
     * Get current question index
     */
    public int getCurrentQuestionIndex() {
        return currentQuestionIndex;
    }
    
    /**
     * Get total number of questions
     */
    public int getTotalQuestions() {
        return questions != null ? questions.size() : 0;
    }
    
    /**
     * Check if there is a next question
     */
    public boolean hasNextQuestion() {
        return currentQuestionIndex < getTotalQuestions() - 1;
    }
    
    /**
     * Check if there is a previous question
     */
    public boolean hasPreviousQuestion() {
        return currentQuestionIndex > 0;
    }
    
    /**
     * Move to next question
     */
    public boolean nextQuestion() {
        if (hasNextQuestion()) {
            currentQuestionIndex++;
            return true;
        }
        return false;
    }
    
    /**
     * Move to previous question
     */
    public boolean previousQuestion() {
        if (hasPreviousQuestion()) {
            currentQuestionIndex--;
            return true;
        }
        return false;
    }
    
    /**
     * Go to a specific question
     */
    public boolean goToQuestion(int questionIndex) {
        if (questionIndex >= 0 && questionIndex < getTotalQuestions()) {
            currentQuestionIndex = questionIndex;
            return true;
        }
        return false;
    }
    
    /**
     * Save user's answer for current question
     */
    public boolean saveAnswer(String answer) {
        if (currentQuestionIndex < 0 || currentQuestionIndex >= getTotalQuestions()) {
            return false;
        }
        
        if (answer != null && (answer.equals("A") || answer.equals("B") || 
                              answer.equals("C") || answer.equals("D"))) {
            userAnswers[currentQuestionIndex] = answer;
            return true;
        }
        
        return false;
    }
    
    /**
     * Get user's answer for current question
     */
    public String getCurrentAnswer() {
        if (currentQuestionIndex < 0 || currentQuestionIndex >= getTotalQuestions()) {
            return null;
        }
        return userAnswers[currentQuestionIndex];
    }
    
    /**
     * Get user's answer for a specific question
     */
    public String getAnswer(int questionIndex) {
        if (questionIndex < 0 || questionIndex >= getTotalQuestions()) {
            return null;
        }
        return userAnswers[questionIndex];
    }
    
    /**
     * Check if current question is answered
     */
    public boolean isCurrentQuestionAnswered() {
        return getCurrentAnswer() != null;
    }
    
    /**
     * Check if all questions are answered
     */
    public boolean areAllQuestionsAnswered() {
        if (userAnswers == null) return false;
        
        for (String answer : userAnswers) {
            if (answer == null) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Get list of unanswered question numbers
     */
    public List<Integer> getUnansweredQuestions() {
        List<Integer> unanswered = new ArrayList<>();
        
        if (userAnswers != null) {
            for (int i = 0; i < userAnswers.length; i++) {
                if (userAnswers[i] == null) {
                    unanswered.add(i + 1); // 1-based question numbers
                }
            }
        }
        
        return unanswered;
    }
    
    /**
     * Check if answer is correct for current question
     */
    public boolean isCurrentAnswerCorrect() {
        Question currentQuestion = getCurrentQuestion();
        String userAnswer = getCurrentAnswer();
        
        if (currentQuestion == null || userAnswer == null) {
            return false;
        }
        
        return userAnswer.equals(currentQuestion.getCorrectAnswer());
    }
    
    /**
     * Check if answer is correct for a specific question
     */
    public boolean isAnswerCorrect(int questionIndex) {
        if (questionIndex < 0 || questionIndex >= getTotalQuestions()) {
            return false;
        }
        
        Question question = questions.get(questionIndex);
        String userAnswer = userAnswers[questionIndex];
        
        if (question == null || userAnswer == null) {
            return false;
        }
        
        return userAnswer.equals(question.getCorrectAnswer());
    }
    
    /**
     * Calculate current score
     */
    public int calculateScore() {
        int score = 0;
        
        if (questions != null && userAnswers != null) {
            for (int i = 0; i < Math.min(questions.size(), userAnswers.length); i++) {
                if (isAnswerCorrect(i)) {
                    score++;
                }
            }
        }
        
        return score;
    }
    
    /**
     * Calculate percentage score
     */
    public double calculatePercentage() {
        if (getTotalQuestions() == 0) return 0.0;
        return (double) calculateScore() / getTotalQuestions() * 100;
    }
    
    /**
     * Submit quiz and save results
     */
    public QuizResult submitQuiz() {
        if (quizCompleted) {
            AlertUtil.showWarning("Quiz Already Submitted", "This quiz has already been submitted.");
            return null;
        }
        
        if (!areAllQuestionsAnswered()) {
            List<Integer> unanswered = getUnansweredQuestions();
            AlertUtil.showWarning("Incomplete Quiz", 
                "Please answer all questions before submitting.\n" +
                "Unanswered questions: " + unanswered.toString());
            return null;
        }
        
        int score = calculateScore();
        QuizResult result = new QuizResult(
            currentUser.getId(),
            currentQuiz.getId(),
            score,
            getTotalQuestions()
        );
        
        if (resultDAO.saveResult(result)) {
            quizCompleted = true;
            return result;
        } else {
            AlertUtil.showError("Error", "Failed to save quiz results. Please try again.");
            return null;
        }
    }
    
    /**
     * Get quiz progress as percentage
     */
    public double getProgress() {
        if (getTotalQuestions() == 0) return 0.0;
        return (double) (currentQuestionIndex + 1) / getTotalQuestions() * 100;
    }
    
    /**
     * Get number of answered questions
     */
    public int getAnsweredQuestionCount() {
        if (userAnswers == null) return 0;
        
        int count = 0;
        for (String answer : userAnswers) {
            if (answer != null) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Validate quiz state before submission
     */
    public ValidationResult validateForSubmission() {
        if (currentQuiz == null) {
            return new ValidationResult(false, "No quiz loaded.");
        }
        
        if (questions == null || questions.isEmpty()) {
            return new ValidationResult(false, "No questions available for this quiz.");
        }
        
        if (quizCompleted) {
            return new ValidationResult(false, "Quiz has already been submitted.");
        }
        
        if (!areAllQuestionsAnswered()) {
            List<Integer> unanswered = getUnansweredQuestions();
            return new ValidationResult(false, 
                "Please answer all questions. Unanswered: " + unanswered.toString());
        }
        
        return new ValidationResult(true, "Quiz is ready for submission.");
    }
    
    /**
     * Reset quiz session
     */
    public void resetQuiz() {
        if (userAnswers != null) {
            for (int i = 0; i < userAnswers.length; i++) {
                userAnswers[i] = null;
            }
        }
        currentQuestionIndex = 0;
        quizCompleted = false;
    }
    
    /**
     * Check if quiz is completed
     */
    public boolean isQuizCompleted() {
        return quizCompleted;
    }
    
    /**
     * Get feedback message for current question
     */
    public String getFeedbackMessage() {
        Question currentQuestion = getCurrentQuestion();
        String userAnswer = getCurrentAnswer();
        
        if (currentQuestion == null || userAnswer == null) {
            return "Please select an answer.";
        }
        
        String correctAnswer = currentQuestion.getCorrectAnswer();
        String correctOption = currentQuestion.getOptionByLetter(correctAnswer);
        
        if (userAnswer.equals(correctAnswer)) {
            return "✓ Correct! " + correctAnswer + ": " + correctOption;
        } else {
            return "✗ Incorrect. The correct answer is " + correctAnswer + ": " + correctOption;
        }
    }
    
    /**
     * Inner class for validation results
     */
    public static class ValidationResult {
        private final boolean valid;
        private final String message;
        
        public ValidationResult(boolean valid, String message) {
            this.valid = valid;
            this.message = message;
        }
        
        public boolean isValid() { return valid; }
        public String getMessage() { return message; }
    }
}
