package com.quiz.controller;

import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.model.QuizResult;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;

import java.util.List;

/**
 * Controller for handling admin-specific business logic
 */
public class AdminController {
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private User currentUser;
    
    public AdminController(User currentUser) {
        this.currentUser = currentUser;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
    }
    
    /**
     * Get all quizzes
     */
    public List<Quiz> getAllQuizzes() {
        return quizDAO.getAllQuizzes();
    }
    
    /**
     * Create a new quiz
     */
    public boolean createQuiz(String title, String description) {
        if (!validateQuizData(title, description)) {
            return false;
        }
        
        Quiz quiz = new Quiz(title.trim(), description.trim(), currentUser.getId());
        
        if (quizDAO.createQuiz(quiz)) {
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to create quiz. Please try again.");
            return false;
        }
    }
    
    /**
     * Update an existing quiz
     */
    public boolean updateQuiz(Quiz quiz, String title, String description) {
        if (!validateQuizData(title, description)) {
            return false;
        }
        
        quiz.setTitle(title.trim());
        quiz.setDescription(description.trim());
        
        if (quizDAO.updateQuiz(quiz)) {
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to update quiz. Please try again.");
            return false;
        }
    }
    
    /**
     * Delete a quiz and all associated data
     */
    public boolean deleteQuiz(Quiz quiz) {
        if (quiz == null) {
            AlertUtil.showWarning("Invalid Operation", "No quiz selected for deletion.");
            return false;
        }
        
        boolean confirmed = AlertUtil.showConfirmation(
            "Delete Quiz",
            "Are you sure you want to delete the quiz '" + quiz.getTitle() + "'?\n" +
            "This will permanently delete:\n" +
            "- All questions in this quiz\n" +
            "- All user results for this quiz\n\n" +
            "This action cannot be undone."
        );
        
        if (!confirmed) {
            return false;
        }
        
        try {
            // Delete questions first due to foreign key constraints
            if (!questionDAO.deleteQuestionsByQuizId(quiz.getId())) {
                AlertUtil.showError("Error", "Failed to delete quiz questions.");
                return false;
            }
            
            // Delete the quiz
            if (quizDAO.deleteQuiz(quiz.getId())) {
                AlertUtil.showSuccess("Success", "Quiz deleted successfully.");
                return true;
            } else {
                AlertUtil.showError("Error", "Failed to delete quiz.");
                return false;
            }
            
        } catch (Exception e) {
            AlertUtil.showError("Error", "An error occurred while deleting the quiz: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Get questions for a specific quiz
     */
    public List<Question> getQuizQuestions(int quizId) {
        return questionDAO.getQuestionsByQuizId(quizId);
    }
    
    /**
     * Get question count for a quiz
     */
    public int getQuestionCount(int quizId) {
        return questionDAO.getQuestionCount(quizId);
    }
    
    /**
     * Add a question to a quiz
     */
    public boolean addQuestion(Question question) {
        if (!validateQuestion(question)) {
            return false;
        }
        
        if (questionDAO.createQuestion(question)) {
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to add question. Please try again.");
            return false;
        }
    }
    
    /**
     * Update an existing question
     */
    public boolean updateQuestion(Question question) {
        if (!validateQuestion(question)) {
            return false;
        }
        
        if (questionDAO.updateQuestion(question)) {
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to update question. Please try again.");
            return false;
        }
    }
    
    /**
     * Delete a question
     */
    public boolean deleteQuestion(Question question) {
        if (question == null) {
            AlertUtil.showWarning("Invalid Operation", "No question selected for deletion.");
            return false;
        }
        
        boolean confirmed = AlertUtil.showConfirmation(
            "Delete Question",
            "Are you sure you want to delete this question?\n\n" +
            "Question: " + question.getQuestionText().substring(0, Math.min(50, question.getQuestionText().length())) + "..."
        );
        
        if (!confirmed) {
            return false;
        }
        
        if (questionDAO.deleteQuestion(question.getId())) {
            AlertUtil.showSuccess("Success", "Question deleted successfully.");
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to delete question.");
            return false;
        }
    }
    
    /**
     * Get quiz results for a specific quiz
     */
    public List<QuizResult> getQuizResults(int quizId) {
        return resultDAO.getResultsByQuizId(quizId);
    }
    
    /**
     * Get overall quiz statistics
     */
    public QuizStatistics getQuizStatistics() {
        List<Quiz> allQuizzes = quizDAO.getAllQuizzes();
        int totalQuizzes = allQuizzes.size();
        int totalQuestions = 0;
        int totalAttempts = 0;
        
        for (Quiz quiz : allQuizzes) {
            totalQuestions += questionDAO.getQuestionCount(quiz.getId());
            totalAttempts += resultDAO.getResultsByQuizId(quiz.getId()).size();
        }
        
        return new QuizStatistics(totalQuizzes, totalQuestions, totalAttempts);
    }
    
    /**
     * Validate quiz data
     */
    private boolean validateQuizData(String title, String description) {
        if (title == null || title.trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Quiz title is required.");
            return false;
        }
        
        if (title.trim().length() < 3) {
            AlertUtil.showError("Validation Error", "Quiz title must be at least 3 characters long.");
            return false;
        }
        
        if (title.trim().length() > 100) {
            AlertUtil.showError("Validation Error", "Quiz title must be less than 100 characters.");
            return false;
        }
        
        if (description == null || description.trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Quiz description is required.");
            return false;
        }
        
        if (description.trim().length() > 500) {
            AlertUtil.showError("Validation Error", "Quiz description must be less than 500 characters.");
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate question data
     */
    private boolean validateQuestion(Question question) {
        if (question == null) {
            AlertUtil.showError("Validation Error", "Question data is invalid.");
            return false;
        }
        
        if (question.getQuestionText() == null || question.getQuestionText().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Question text is required.");
            return false;
        }
        
        if (question.getQuestionText().trim().length() < 10) {
            AlertUtil.showError("Validation Error", "Question text must be at least 10 characters long.");
            return false;
        }
        
        if (question.getOptionA() == null || question.getOptionA().trim().isEmpty() ||
            question.getOptionB() == null || question.getOptionB().trim().isEmpty() ||
            question.getOptionC() == null || question.getOptionC().trim().isEmpty() ||
            question.getOptionD() == null || question.getOptionD().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "All answer options (A, B, C, D) are required.");
            return false;
        }
        
        if (question.getCorrectAnswer() == null || 
            (!question.getCorrectAnswer().equals("A") && 
             !question.getCorrectAnswer().equals("B") && 
             !question.getCorrectAnswer().equals("C") && 
             !question.getCorrectAnswer().equals("D"))) {
            AlertUtil.showError("Validation Error", "Please select a valid correct answer (A, B, C, or D).");
            return false;
        }
        
        // Check for duplicate options
        String[] options = {
            question.getOptionA().trim(),
            question.getOptionB().trim(),
            question.getOptionC().trim(),
            question.getOptionD().trim()
        };
        
        for (int i = 0; i < options.length; i++) {
            for (int j = i + 1; j < options.length; j++) {
                if (options[i].equalsIgnoreCase(options[j])) {
                    AlertUtil.showError("Validation Error", "Answer options must be unique.");
                    return false;
                }
            }
        }
        
        return true;
    }
    
    /**
     * Inner class for quiz statistics
     */
    public static class QuizStatistics {
        private final int totalQuizzes;
        private final int totalQuestions;
        private final int totalAttempts;
        
        public QuizStatistics(int totalQuizzes, int totalQuestions, int totalAttempts) {
            this.totalQuizzes = totalQuizzes;
            this.totalQuestions = totalQuestions;
            this.totalAttempts = totalAttempts;
        }
        
        public int getTotalQuizzes() { return totalQuizzes; }
        public int getTotalQuestions() { return totalQuestions; }
        public int getTotalAttempts() { return totalAttempts; }
        
        @Override
        public String toString() {
            return String.format(
                "Total Quizzes: %d\nTotal Questions: %d\nTotal Attempts: %d",
                totalQuizzes, totalQuestions, totalAttempts
            );
        }
    }
}
