package com.quiz.view;

import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.util.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * View for creating and editing quizzes
 */
public class CreateQuizView {
    private Stage stage;
    private Quiz quiz;
    private Runnable onSaveCallback;
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private TextField titleField;
    private TextArea descriptionArea;
    private TableView<Question> questionTable;
    private ObservableList<Question> questionList;
    
    public CreateQuizView(Quiz quiz, Runnable onSaveCallback) {
        this.quiz = quiz;
        this.onSaveCallback = onSaveCallback;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.questionList = FXCollections.observableArrayList();
        createView();
        
        if (quiz != null) {
            loadQuizData();
        }
    }
    
    private void createView() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(quiz == null ? "Create Quiz" : "Edit Quiz");
        stage.setMinWidth(800);
        stage.setMinHeight(600);
        
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(20));
        
        // Quiz details section
        VBox quizDetails = createQuizDetailsSection();
        
        // Questions section
        VBox questionsSection = createQuestionsSection();
        
        // Buttons
        HBox buttonBox = createButtonBox();
        
        mainContainer.getChildren().addAll(quizDetails, questionsSection, buttonBox);
        
        Scene scene = new Scene(new ScrollPane(mainContainer), 800, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
    }
    
    private VBox createQuizDetailsSection() {
        VBox section = new VBox(10);
        
        Label sectionLabel = new Label("Quiz Details");
        sectionLabel.getStyleClass().add("section-title");
        
        // Title
        Label titleLabel = new Label("Title:");
        titleField = new TextField();
        titleField.setPromptText("Enter quiz title");
        
        // Description
        Label descLabel = new Label("Description:");
        descriptionArea = new TextArea();
        descriptionArea.setPromptText("Enter quiz description");
        descriptionArea.setPrefRowCount(3);
        
        section.getChildren().addAll(sectionLabel, titleLabel, titleField, descLabel, descriptionArea);
        return section;
    }
    
    private VBox createQuestionsSection() {
        VBox section = new VBox(10);
        
        Label sectionLabel = new Label("Questions");
        sectionLabel.getStyleClass().add("section-title");
        
        // Question table
        createQuestionTable();
        
        // Question actions
        HBox questionActions = new HBox(10);
        questionActions.setAlignment(Pos.CENTER_LEFT);
        
        Button addQuestionButton = new Button("Add Question");
        addQuestionButton.getStyleClass().add("primary-button");
        addQuestionButton.setOnAction(e -> addQuestion());
        
        Button editQuestionButton = new Button("Edit Question");
        editQuestionButton.getStyleClass().add("secondary-button");
        editQuestionButton.setOnAction(e -> editQuestion());
        
        Button deleteQuestionButton = new Button("Delete Question");
        deleteQuestionButton.getStyleClass().add("danger-button");
        deleteQuestionButton.setOnAction(e -> deleteQuestion());
        
        questionActions.getChildren().addAll(addQuestionButton, editQuestionButton, deleteQuestionButton);
        
        section.getChildren().addAll(sectionLabel, questionTable, questionActions);
        return section;
    }
    
    private void createQuestionTable() {
        questionTable = new TableView<>();
        questionTable.setItems(questionList);
        
        TableColumn<Question, String> questionColumn = new TableColumn<>("Question");
        questionColumn.setCellValueFactory(new PropertyValueFactory<>("questionText"));
        questionColumn.setPrefWidth(300);
        
        TableColumn<Question, String> answerColumn = new TableColumn<>("Correct Answer");
        answerColumn.setCellValueFactory(cellData -> {
            Question q = cellData.getValue();
            String answer = q.getCorrectAnswer() + ": " + q.getOptionByLetter(q.getCorrectAnswer());
            return new javafx.beans.property.SimpleStringProperty(answer);
        });
        answerColumn.setPrefWidth(200);
        
        questionTable.getColumns().addAll(questionColumn, answerColumn);
        questionTable.setPrefHeight(200);
    }
    
    private HBox createButtonBox() {
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        
        Button saveButton = new Button("Save Quiz");
        saveButton.getStyleClass().add("primary-button");
        saveButton.setOnAction(e -> saveQuiz());
        
        Button cancelButton = new Button("Cancel");
        cancelButton.getStyleClass().add("secondary-button");
        cancelButton.setOnAction(e -> stage.close());
        
        buttonBox.getChildren().addAll(cancelButton, saveButton);
        return buttonBox;
    }
    
    private void loadQuizData() {
        titleField.setText(quiz.getTitle());
        descriptionArea.setText(quiz.getDescription());
        
        // Load questions
        questionList.clear();
        questionList.addAll(questionDAO.getQuestionsByQuizId(quiz.getId()));
    }
    
    private void addQuestion() {
        showQuestionDialog(null);
    }
    
    private void editQuestion() {
        Question selectedQuestion = questionTable.getSelectionModel().getSelectedItem();
        if (selectedQuestion == null) {
            AlertUtil.showWarning("No Selection", "Please select a question to edit.");
            return;
        }
        
        showQuestionDialog(selectedQuestion);
    }
    
    private void deleteQuestion() {
        Question selectedQuestion = questionTable.getSelectionModel().getSelectedItem();
        if (selectedQuestion == null) {
            AlertUtil.showWarning("No Selection", "Please select a question to delete.");
            return;
        }
        
        boolean confirmed = AlertUtil.showConfirmation(
            "Delete Question",
            "Are you sure you want to delete this question?"
        );
        
        if (confirmed) {
            questionList.remove(selectedQuestion);
        }
    }
    
    private void showQuestionDialog(Question question) {
        Stage dialog = new Stage();
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle(question == null ? "Add Question" : "Edit Question");
        
        VBox dialogContent = new VBox(15);
        dialogContent.setPadding(new Insets(20));
        
        // Question text
        Label questionLabel = new Label("Question:");
        TextArea questionArea = new TextArea();
        questionArea.setPromptText("Enter question text");
        questionArea.setPrefRowCount(3);
        
        // Options
        Label optionALabel = new Label("Option A:");
        TextField optionAField = new TextField();
        
        Label optionBLabel = new Label("Option B:");
        TextField optionBField = new TextField();
        
        Label optionCLabel = new Label("Option C:");
        TextField optionCField = new TextField();
        
        Label optionDLabel = new Label("Option D:");
        TextField optionDField = new TextField();
        
        // Correct answer
        Label correctLabel = new Label("Correct Answer:");
        ComboBox<String> correctCombo = new ComboBox<>();
        correctCombo.getItems().addAll("A", "B", "C", "D");
        
        // Load existing data if editing
        if (question != null) {
            questionArea.setText(question.getQuestionText());
            optionAField.setText(question.getOptionA());
            optionBField.setText(question.getOptionB());
            optionCField.setText(question.getOptionC());
            optionDField.setText(question.getOptionD());
            correctCombo.setValue(question.getCorrectAnswer());
        }
        
        // Buttons
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        
        Button saveButton = new Button("Save");
        saveButton.getStyleClass().add("primary-button");
        saveButton.setOnAction(e -> {
            if (validateQuestion(questionArea, optionAField, optionBField, optionCField, optionDField, correctCombo)) {
                if (question == null) {
                    // Add new question
                    Question newQuestion = new Question(
                        0, // quiz ID will be set when saving
                        questionArea.getText().trim(),
                        optionAField.getText().trim(),
                        optionBField.getText().trim(),
                        optionCField.getText().trim(),
                        optionDField.getText().trim(),
                        correctCombo.getValue()
                    );
                    questionList.add(newQuestion);
                } else {
                    // Update existing question
                    question.setQuestionText(questionArea.getText().trim());
                    question.setOptionA(optionAField.getText().trim());
                    question.setOptionB(optionBField.getText().trim());
                    question.setOptionC(optionCField.getText().trim());
                    question.setOptionD(optionDField.getText().trim());
                    question.setCorrectAnswer(correctCombo.getValue());
                    questionTable.refresh();
                }
                dialog.close();
            }
        });
        
        Button cancelButton = new Button("Cancel");
        cancelButton.getStyleClass().add("secondary-button");
        cancelButton.setOnAction(e -> dialog.close());
        
        buttonBox.getChildren().addAll(cancelButton, saveButton);
        
        dialogContent.getChildren().addAll(
            questionLabel, questionArea,
            optionALabel, optionAField,
            optionBLabel, optionBField,
            optionCLabel, optionCField,
            optionDLabel, optionDField,
            correctLabel, correctCombo,
            buttonBox
        );
        
        Scene dialogScene = new Scene(new ScrollPane(dialogContent), 500, 600);
        dialogScene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        dialog.setScene(dialogScene);
        dialog.showAndWait();
    }
    
    private boolean validateQuestion(TextArea questionArea, TextField optionA, TextField optionB, 
                                   TextField optionC, TextField optionD, ComboBox<String> correct) {
        if (questionArea.getText().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Question text is required.");
            return false;
        }
        
        if (optionA.getText().trim().isEmpty() || optionB.getText().trim().isEmpty() ||
            optionC.getText().trim().isEmpty() || optionD.getText().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "All options are required.");
            return false;
        }
        
        if (correct.getValue() == null) {
            AlertUtil.showError("Validation Error", "Please select the correct answer.");
            return false;
        }
        
        return true;
    }
    
    private void saveQuiz() {
        if (!validateQuiz()) {
            return;
        }
        
        if (questionList.isEmpty()) {
            AlertUtil.showError("Validation Error", "Please add at least one question.");
            return;
        }
        
        boolean isNewQuiz = (quiz == null);
        
        if (isNewQuiz) {
            // Create new quiz
            quiz = new Quiz(titleField.getText().trim(), descriptionArea.getText().trim(), 1); // Assuming admin user ID = 1
            if (!quizDAO.createQuiz(quiz)) {
                AlertUtil.showError("Error", "Failed to create quiz.");
                return;
            }
        } else {
            // Update existing quiz
            quiz.setTitle(titleField.getText().trim());
            quiz.setDescription(descriptionArea.getText().trim());
            if (!quizDAO.updateQuiz(quiz)) {
                AlertUtil.showError("Error", "Failed to update quiz.");
                return;
            }
            
            // Delete existing questions
            questionDAO.deleteQuestionsByQuizId(quiz.getId());
        }
        
        // Save questions
        for (Question question : questionList) {
            question.setQuizId(quiz.getId());
            if (!questionDAO.createQuestion(question)) {
                AlertUtil.showError("Error", "Failed to save question: " + question.getQuestionText());
                return;
            }
        }
        
        AlertUtil.showSuccess("Success", "Quiz saved successfully!");
        
        if (onSaveCallback != null) {
            onSaveCallback.run();
        }
        
        stage.close();
    }
    
    private boolean validateQuiz() {
        if (titleField.getText().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Quiz title is required.");
            return false;
        }
        
        if (descriptionArea.getText().trim().isEmpty()) {
            AlertUtil.showError("Validation Error", "Quiz description is required.");
            return false;
        }
        
        return true;
    }
    
    public void show() {
        stage.show();
    }
}
