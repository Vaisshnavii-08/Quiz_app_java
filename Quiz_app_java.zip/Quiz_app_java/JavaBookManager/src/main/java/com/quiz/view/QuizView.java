package com.quiz.view;

import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.model.QuizResult;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.List;

/**
 * View for taking a quiz
 */
public class QuizView {
    private Stage stage;
    private Quiz quiz;
    private User user;
    private Runnable onCompleteCallback;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private List<Question> questions;
    private int currentQuestionIndex;
    private int score;
    private String[] userAnswers;
    
    // UI Components
    private VBox mainContainer;
    private Label questionNumberLabel;
    private Label questionTextLabel;
    private ToggleGroup answerGroup;
    private RadioButton optionA, optionB, optionC, optionD;
    private Button prevButton, nextButton, submitButton;
    private ProgressBar progressBar;
    private Label feedbackLabel;
    
    public QuizView(Quiz quiz, User user, Runnable onCompleteCallback) {
        this.quiz = quiz;
        this.user = user;
        this.onCompleteCallback = onCompleteCallback;
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
        this.currentQuestionIndex = 0;
        this.score = 0;
        
        loadQuestions();
        createView();
        displayQuestion();
    }
    
    private void loadQuestions() {
        questions = questionDAO.getQuestionsByQuizId(quiz.getId());
        userAnswers = new String[questions.size()];
    }
    
    private void createView() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Taking Quiz: " + quiz.getTitle());
        stage.setMinWidth(700);
        stage.setMinHeight(500);
        
        mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(30));
        mainContainer.getStyleClass().add("quiz-container");
        
        // Header
        VBox header = createHeader();
        
        // Question content
        VBox questionContent = createQuestionContent();
        
        // Navigation
        HBox navigation = createNavigation();
        
        // Feedback area (initially hidden)
        feedbackLabel = new Label();
        feedbackLabel.getStyleClass().add("feedback-label");
        feedbackLabel.setVisible(false);
        feedbackLabel.setManaged(false);
        
        mainContainer.getChildren().addAll(header, questionContent, feedbackLabel, navigation);
        
        Scene scene = new Scene(new ScrollPane(mainContainer), 700, 500);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
        
        // Prevent closing without confirmation
        stage.setOnCloseRequest(e -> {
            e.consume();
            exitQuiz();
        });
    }
    
    private VBox createHeader() {
        VBox header = new VBox(10);
        header.setAlignment(Pos.CENTER);
        
        Label titleLabel = new Label(quiz.getTitle());
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titleLabel.getStyleClass().add("quiz-title");
        
        questionNumberLabel = new Label();
        questionNumberLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        questionNumberLabel.getStyleClass().add("question-number");
        
        progressBar = new ProgressBar();
        progressBar.setPrefWidth(400);
        progressBar.getStyleClass().add("quiz-progress");
        
        header.getChildren().addAll(titleLabel, questionNumberLabel, progressBar);
        return header;
    }
    
    private VBox createQuestionContent() {
        VBox content = new VBox(20);
        content.setAlignment(Pos.TOP_LEFT);
        
        // Question text
        questionTextLabel = new Label();
        questionTextLabel.setWrapText(true);
        questionTextLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        questionTextLabel.getStyleClass().add("question-text");
        questionTextLabel.setPrefWidth(600);
        
        // Answer options
        VBox optionsBox = createOptionsBox();
        
        content.getChildren().addAll(questionTextLabel, optionsBox);
        return content;
    }
    
    private VBox createOptionsBox() {
        VBox optionsBox = new VBox(15);
        optionsBox.setPadding(new Insets(20, 0, 0, 20));
        
        answerGroup = new ToggleGroup();
        
        optionA = new RadioButton();
        optionA.setToggleGroup(answerGroup);
        optionA.getStyleClass().add("quiz-option");
        optionA.setWrapText(true);
        optionA.setPrefWidth(550);
        
        optionB = new RadioButton();
        optionB.setToggleGroup(answerGroup);
        optionB.getStyleClass().add("quiz-option");
        optionB.setWrapText(true);
        optionB.setPrefWidth(550);
        
        optionC = new RadioButton();
        optionC.setToggleGroup(answerGroup);
        optionC.getStyleClass().add("quiz-option");
        optionC.setWrapText(true);
        optionC.setPrefWidth(550);
        
        optionD = new RadioButton();
        optionD.setToggleGroup(answerGroup);
        optionD.getStyleClass().add("quiz-option");
        optionD.setWrapText(true);
        optionD.setPrefWidth(550);
        
        optionsBox.getChildren().addAll(optionA, optionB, optionC, optionD);
        return optionsBox;
    }
    
    private HBox createNavigation() {
        HBox navigation = new HBox(15);
        navigation.setAlignment(Pos.CENTER);
        navigation.setPadding(new Insets(20, 0, 0, 0));
        
        prevButton = new Button("Previous");
        prevButton.getStyleClass().add("secondary-button");
        prevButton.setOnAction(e -> previousQuestion());
        
        nextButton = new Button("Next");
        nextButton.getStyleClass().add("primary-button");
        nextButton.setOnAction(e -> nextQuestion());
        
        submitButton = new Button("Submit Quiz");
        submitButton.getStyleClass().add("success-button");
        submitButton.setOnAction(e -> submitQuiz());
        submitButton.setVisible(false);
        
        Button exitButton = new Button("Exit Quiz");
        exitButton.getStyleClass().add("danger-button");
        exitButton.setOnAction(e -> exitQuiz());
        
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        
        navigation.getChildren().addAll(prevButton, nextButton, submitButton, spacer, exitButton);
        return navigation;
    }
    
    private void displayQuestion() {
        if (currentQuestionIndex < 0 || currentQuestionIndex >= questions.size()) {
            return;
        }
        
        Question question = questions.get(currentQuestionIndex);
        
        // Update header
        questionNumberLabel.setText(String.format("Question %d of %d", 
            currentQuestionIndex + 1, questions.size()));
        progressBar.setProgress((double) (currentQuestionIndex + 1) / questions.size());
        
        // Update question content
        questionTextLabel.setText(question.getQuestionText());
        optionA.setText("A. " + question.getOptionA());
        optionB.setText("B. " + question.getOptionB());
        optionC.setText("C. " + question.getOptionC());
        optionD.setText("D. " + question.getOptionD());
        
        // Clear previous selection
        answerGroup.selectToggle(null);
        
        // Restore user's previous answer if any
        if (userAnswers[currentQuestionIndex] != null) {
            switch (userAnswers[currentQuestionIndex]) {
                case "A": answerGroup.selectToggle(optionA); break;
                case "B": answerGroup.selectToggle(optionB); break;
                case "C": answerGroup.selectToggle(optionC); break;
                case "D": answerGroup.selectToggle(optionD); break;
            }
        }
        
        // Update navigation buttons
        prevButton.setDisable(currentQuestionIndex == 0);
        nextButton.setVisible(currentQuestionIndex < questions.size() - 1);
        submitButton.setVisible(currentQuestionIndex == questions.size() - 1);
        
        // Hide feedback
        feedbackLabel.setVisible(false);
        feedbackLabel.setManaged(false);
    }
    
    private void previousQuestion() {
        saveCurrentAnswer();
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            displayQuestion();
        }
    }
    
    private void nextQuestion() {
        if (answerGroup.getSelectedToggle() == null) {
            AlertUtil.showWarning("No Answer", "Please select an answer before proceeding.");
            return;
        }
        
        saveCurrentAnswer();
        showFeedback();
        
        // Wait a moment before moving to next question
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(2), e -> {
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                displayQuestion();
            }
        }));
        timeline.play();
    }
    
    private void saveCurrentAnswer() {
        RadioButton selected = (RadioButton) answerGroup.getSelectedToggle();
        if (selected != null) {
            if (selected == optionA) userAnswers[currentQuestionIndex] = "A";
            else if (selected == optionB) userAnswers[currentQuestionIndex] = "B";
            else if (selected == optionC) userAnswers[currentQuestionIndex] = "C";
            else if (selected == optionD) userAnswers[currentQuestionIndex] = "D";
        }
    }
    
    private void showFeedback() {
        Question question = questions.get(currentQuestionIndex);
        String userAnswer = userAnswers[currentQuestionIndex];
        String correctAnswer = question.getCorrectAnswer();
        
        if (userAnswer.equals(correctAnswer)) {
            feedbackLabel.setText("✓ Correct! " + correctAnswer + ": " + question.getOptionByLetter(correctAnswer));
            feedbackLabel.getStyleClass().removeAll("feedback-incorrect");
            feedbackLabel.getStyleClass().add("feedback-correct");
            score++;
        } else {
            feedbackLabel.setText("✗ Incorrect. The correct answer is " + correctAnswer + ": " + question.getOptionByLetter(correctAnswer));
            feedbackLabel.getStyleClass().removeAll("feedback-correct");
            feedbackLabel.getStyleClass().add("feedback-incorrect");
        }
        
        feedbackLabel.setVisible(true);
        feedbackLabel.setManaged(true);
    }
    
    private void submitQuiz() {
        saveCurrentAnswer();
        
        // Check if all questions are answered
        for (int i = 0; i < userAnswers.length; i++) {
            if (userAnswers[i] == null) {
                AlertUtil.showWarning("Incomplete Quiz", 
                    "Please answer all questions before submitting. Question " + (i + 1) + " is not answered.");
                currentQuestionIndex = i;
                displayQuestion();
                return;
            }
        }
        
        // Calculate final score
        score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (userAnswers[i] != null && userAnswers[i].equals(questions.get(i).getCorrectAnswer())) {
                score++;
            }
        }
        
        // Save result to database
        QuizResult result = new QuizResult(user.getId(), quiz.getId(), score, questions.size());
        if (resultDAO.saveResult(result)) {
            showResults();
        } else {
            AlertUtil.showError("Error", "Failed to save quiz results.");
        }
    }
    
    private void showResults() {
        double percentage = (double) score / questions.size() * 100;
        
        Alert resultAlert = new Alert(Alert.AlertType.INFORMATION);
        resultAlert.setTitle("Quiz Completed");
        resultAlert.setHeaderText("Quiz Results");
        resultAlert.setContentText(String.format(
            "Quiz: %s\n\nScore: %d out of %d\nPercentage: %.1f%%\n\n%s",
            quiz.getTitle(),
            score,
            questions.size(),
            percentage,
            getPerformanceMessage(percentage)
        ));
        
        resultAlert.showAndWait();
        
        if (onCompleteCallback != null) {
            onCompleteCallback.run();
        }
        
        stage.close();
    }
    
    private String getPerformanceMessage(double percentage) {
        if (percentage >= 90) return "Excellent work!";
        else if (percentage >= 80) return "Great job!";
        else if (percentage >= 70) return "Good performance!";
        else if (percentage >= 60) return "Fair performance. Keep practicing!";
        else return "You might want to review the material and try again.";
    }
    
    private void exitQuiz() {
        boolean confirmed = AlertUtil.showConfirmation(
            "Exit Quiz",
            "Are you sure you want to exit the quiz? Your progress will be lost."
        );
        
        if (confirmed) {
            stage.close();
        }
    }
    
    public void show() {
        stage.show();
    }
}
