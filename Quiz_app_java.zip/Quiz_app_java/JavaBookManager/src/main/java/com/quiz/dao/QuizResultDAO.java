package com.quiz.dao;

import com.quiz.database.DatabaseManager;
import com.quiz.model.QuizResult;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for QuizResult operations
 */
public class QuizResultDAO {
    
    /**
     * Save quiz result
     */
    public boolean saveResult(QuizResult result) {
        String sql = "INSERT INTO quiz_results (user_id, quiz_id, score, total_questions, taken_at) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, result.getUserId());
            pstmt.setInt(2, result.getQuizId());
            pstmt.setInt(3, result.getScore());
            pstmt.setInt(4, result.getTotalQuestions());
            pstmt.setTimestamp(5, Timestamp.valueOf(result.getTakenAt()));
            
            int rowsAffected = pstmt.executeUpdate();
            
            if (rowsAffected > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        result.setId(rs.getInt(1));
                    }
                }
                return true;
            }
            
        } catch (SQLException e) {
            System.err.println("Error saving quiz result: " + e.getMessage());
        }
        
        return false;
    }
    
    /**
     * Get results by user ID
     */
    public List<QuizResult> getResultsByUserId(int userId) {
        List<QuizResult> results = new ArrayList<>();
        String sql = """
            SELECT qr.*, q.title as quiz_title 
            FROM quiz_results qr 
            JOIN quizzes q ON qr.quiz_id = q.id 
            WHERE qr.user_id = ? 
            ORDER BY qr.taken_at DESC
            """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    QuizResult result = new QuizResult(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("quiz_id"),
                        rs.getInt("score"),
                        rs.getInt("total_questions"),
                        rs.getTimestamp("taken_at").toLocalDateTime()
                    );
                    result.setQuizTitle(rs.getString("quiz_title"));
                    results.add(result);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting user results: " + e.getMessage());
        }
        
        return results;
    }
    
    /**
     * Get results by quiz ID
     */
    public List<QuizResult> getResultsByQuizId(int quizId) {
        List<QuizResult> results = new ArrayList<>();
        String sql = """
            SELECT qr.*, u.username 
            FROM quiz_results qr 
            JOIN users u ON qr.user_id = u.id 
            WHERE qr.quiz_id = ? 
            ORDER BY qr.score DESC, qr.taken_at DESC
            """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    QuizResult result = new QuizResult(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("quiz_id"),
                        rs.getInt("score"),
                        rs.getInt("total_questions"),
                        rs.getTimestamp("taken_at").toLocalDateTime()
                    );
                    results.add(result);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting quiz results: " + e.getMessage());
        }
        
        return results;
    }
    
    /**
     * Get top scores across all quizzes
     */
    public List<QuizResult> getTopScores(int limit) {
        List<QuizResult> results = new ArrayList<>();
        String sql = """
            SELECT qr.*, q.title as quiz_title, u.username 
            FROM quiz_results qr 
            JOIN quizzes q ON qr.quiz_id = q.id 
            JOIN users u ON qr.user_id = u.id 
            ORDER BY (CAST(qr.score AS REAL) / qr.total_questions) DESC, qr.taken_at DESC 
            LIMIT ?
            """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, limit);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    QuizResult result = new QuizResult(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("quiz_id"),
                        rs.getInt("score"),
                        rs.getInt("total_questions"),
                        rs.getTimestamp("taken_at").toLocalDateTime()
                    );
                    result.setQuizTitle(rs.getString("quiz_title"));
                    results.add(result);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting top scores: " + e.getMessage());
        }
        
        return results;
    }
    
    /**
     * Get user's best score for a specific quiz
     */
    public QuizResult getBestScore(int userId, int quizId) {
        String sql = """
            SELECT * FROM quiz_results 
            WHERE user_id = ? AND quiz_id = ? 
            ORDER BY (CAST(score AS REAL) / total_questions) DESC 
            LIMIT 1
            """;
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.setInt(2, quizId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new QuizResult(
                        rs.getInt("id"),
                        rs.getInt("user_id"),
                        rs.getInt("quiz_id"),
                        rs.getInt("score"),
                        rs.getInt("total_questions"),
                        rs.getTimestamp("taken_at").toLocalDateTime()
                    );
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting best score: " + e.getMessage());
        }
        
        return null;
    }
}
