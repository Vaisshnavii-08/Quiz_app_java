package com.quiz.controller;

import com.quiz.dao.QuizDAO;
import com.quiz.dao.QuestionDAO;
import com.quiz.dao.QuizResultDAO;
import com.quiz.model.Quiz;
import com.quiz.model.Question;
import com.quiz.model.QuizResult;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controller for handling user-specific business logic
 */
public class UserController {
    private QuizDAO quizDAO;
    private QuestionDAO questionDAO;
    private QuizResultDAO resultDAO;
    private User currentUser;
    
    public UserController(User currentUser) {
        this.currentUser = currentUser;
        this.quizDAO = new QuizDAO();
        this.questionDAO = new QuestionDAO();
        this.resultDAO = new QuizResultDAO();
    }
    
    /**
     * Get all available quizzes for the user
     */
    public List<Quiz> getAvailableQuizzes() {
        List<Quiz> allQuizzes = quizDAO.getAllQuizzes();
        
        // Filter quizzes that have at least one question
        return allQuizzes.stream()
                .filter(quiz -> questionDAO.getQuestionCount(quiz.getId()) > 0)
                .collect(Collectors.toList());
    }
    
    /**
     * Get user's quiz history
     */
    public List<QuizResult> getUserQuizHistory() {
        return resultDAO.getResultsByUserId(currentUser.getId());
    }
    
    /**
     * Get user's best score for a specific quiz
     */
    public QuizResult getBestScore(int quizId) {
        return resultDAO.getBestScore(currentUser.getId(), quizId);
    }
    
    /**
     * Check if user has taken a specific quiz
     */
    public boolean hasUserTakenQuiz(int quizId) {
        List<QuizResult> userResults = resultDAO.getResultsByUserId(currentUser.getId());
        return userResults.stream().anyMatch(result -> result.getQuizId() == quizId);
    }
    
    /**
     * Get quiz details including question count
     */
    public QuizDetails getQuizDetails(Quiz quiz) {
        if (quiz == null) {
            return null;
        }
        
        int questionCount = questionDAO.getQuestionCount(quiz.getId());
        QuizResult bestScore = getBestScore(quiz.getId());
        boolean hasTaken = hasUserTakenQuiz(quiz.getId());
        
        return new QuizDetails(quiz, questionCount, bestScore, hasTaken);
    }
    
    /**
     * Validate if user can take a quiz
     */
    public boolean canTakeQuiz(Quiz quiz) {
        if (quiz == null) {
            AlertUtil.showError("Error", "Invalid quiz selected.");
            return false;
        }
        
        int questionCount = questionDAO.getQuestionCount(quiz.getId());
        if (questionCount == 0) {
            AlertUtil.showWarning("No Questions", 
                "This quiz has no questions available. Please contact the administrator.");
            return false;
        }
        
        return true;
    }
    
    /**
     * Get questions for a quiz (for taking the quiz)
     */
    public List<Question> getQuizQuestions(int quizId) {
        return questionDAO.getQuestionsByQuizId(quizId);
    }
    
    /**
     * Submit quiz results
     */
    public boolean submitQuizResult(int quizId, int score, int totalQuestions) {
        if (score < 0 || score > totalQuestions) {
            AlertUtil.showError("Invalid Score", "Score must be between 0 and " + totalQuestions);
            return false;
        }
        
        QuizResult result = new QuizResult(currentUser.getId(), quizId, score, totalQuestions);
        
        if (resultDAO.saveResult(result)) {
            return true;
        } else {
            AlertUtil.showError("Error", "Failed to save quiz result. Please try again.");
            return false;
        }
    }
    
    /**
     * Get user's quiz performance statistics
     */
    public UserPerformanceStats getUserPerformanceStats() {
        List<QuizResult> userResults = getUserQuizHistory();
        
        if (userResults.isEmpty()) {
            return new UserPerformanceStats(0, 0, 0, 0, 0);
        }
        
        int totalQuizzesTaken = userResults.size();
        int totalQuestionsAnswered = userResults.stream()
                .mapToInt(QuizResult::getTotalQuestions)
                .sum();
        int totalCorrectAnswers = userResults.stream()
                .mapToInt(QuizResult::getScore)
                .sum();
        
        double averageScore = userResults.stream()
                .mapToDouble(QuizResult::getPercentage)
                .average()
                .orElse(0.0);
        
        double bestScore = userResults.stream()
                .mapToDouble(QuizResult::getPercentage)
                .max()
                .orElse(0.0);
        
        return new UserPerformanceStats(
                totalQuizzesTaken,
                totalQuestionsAnswered,
                totalCorrectAnswers,
                averageScore,
                bestScore
        );
    }
    
    /**
     * Get user's ranking compared to other users
     */
    public UserRanking getUserRanking() {
        List<QuizResult> allResults = resultDAO.getTopScores(1000); // Get top 1000 scores
        List<QuizResult> userResults = getUserQuizHistory();
        
        if (userResults.isEmpty()) {
            return new UserRanking(0, 0, 0.0);
        }
        
        double userAverageScore = userResults.stream()
                .mapToDouble(QuizResult::getPercentage)
                .average()
                .orElse(0.0);
        
        // Count how many users have better average scores
        // This is a simplified ranking - in a real application, you might want more sophisticated ranking
        long betterUsers = allResults.stream()
                .filter(result -> result.getPercentage() > userAverageScore)
                .map(QuizResult::getUserId)
                .distinct()
                .count();
        
        int totalUsers = (int) allResults.stream()
                .map(QuizResult::getUserId)
                .distinct()
                .count();
        
        int userRank = (int) betterUsers + 1;
        
        return new UserRanking(userRank, totalUsers, userAverageScore);
    }
    
    /**
     * Get recommended quizzes for the user
     */
    public List<Quiz> getRecommendedQuizzes() {
        List<Quiz> availableQuizzes = getAvailableQuizzes();
        List<QuizResult> userResults = getUserQuizHistory();
        
        // Recommend quizzes that the user hasn't taken yet
        List<Integer> takenQuizIds = userResults.stream()
                .map(QuizResult::getQuizId)
                .collect(Collectors.toList());
        
        return availableQuizzes.stream()
                .filter(quiz -> !takenQuizIds.contains(quiz.getId()))
                .limit(5) // Limit to top 5 recommendations
                .collect(Collectors.toList());
    }
    
    /**
     * Inner class for quiz details with user-specific information
     */
    public static class QuizDetails {
        private final Quiz quiz;
        private final int questionCount;
        private final QuizResult bestScore;
        private final boolean hasTaken;
        
        public QuizDetails(Quiz quiz, int questionCount, QuizResult bestScore, boolean hasTaken) {
            this.quiz = quiz;
            this.questionCount = questionCount;
            this.bestScore = bestScore;
            this.hasTaken = hasTaken;
        }
        
        public Quiz getQuiz() { return quiz; }
        public int getQuestionCount() { return questionCount; }
        public QuizResult getBestScore() { return bestScore; }
        public boolean hasTaken() { return hasTaken; }
        
        public String getStatusText() {
            if (bestScore != null) {
                return String.format("Best: %.1f%%", bestScore.getPercentage());
            } else {
                return "Not taken";
            }
        }
    }
    
    /**
     * Inner class for user performance statistics
     */
    public static class UserPerformanceStats {
        private final int totalQuizzesTaken;
        private final int totalQuestionsAnswered;
        private final int totalCorrectAnswers;
        private final double averageScore;
        private final double bestScore;
        
        public UserPerformanceStats(int totalQuizzesTaken, int totalQuestionsAnswered, 
                                  int totalCorrectAnswers, double averageScore, double bestScore) {
            this.totalQuizzesTaken = totalQuizzesTaken;
            this.totalQuestionsAnswered = totalQuestionsAnswered;
            this.totalCorrectAnswers = totalCorrectAnswers;
            this.averageScore = averageScore;
            this.bestScore = bestScore;
        }
        
        public int getTotalQuizzesTaken() { return totalQuizzesTaken; }
        public int getTotalQuestionsAnswered() { return totalQuestionsAnswered; }
        public int getTotalCorrectAnswers() { return totalCorrectAnswers; }
        public double getAverageScore() { return averageScore; }
        public double getBestScore() { return bestScore; }
        
        public double getAccuracyRate() {
            return totalQuestionsAnswered > 0 ? 
                   (double) totalCorrectAnswers / totalQuestionsAnswered * 100 : 0.0;
        }
        
        @Override
        public String toString() {
            return String.format(
                "Quizzes Taken: %d\n" +
                "Questions Answered: %d\n" +
                "Correct Answers: %d\n" +
                "Accuracy Rate: %.1f%%\n" +
                "Average Score: %.1f%%\n" +
                "Best Score: %.1f%%",
                totalQuizzesTaken, totalQuestionsAnswered, totalCorrectAnswers,
                getAccuracyRate(), averageScore, bestScore
            );
        }
    }
    
    /**
     * Inner class for user ranking information
     */
    public static class UserRanking {
        private final int rank;
        private final int totalUsers;
        private final double averageScore;
        
        public UserRanking(int rank, int totalUsers, double averageScore) {
            this.rank = rank;
            this.totalUsers = totalUsers;
            this.averageScore = averageScore;
        }
        
        public int getRank() { return rank; }
        public int getTotalUsers() { return totalUsers; }
        public double getAverageScore() { return averageScore; }
        
        public String getRankText() {
            if (totalUsers == 0) {
                return "No ranking available";
            }
            return String.format("Rank %d of %d users", rank, totalUsers);
        }
        
        public double getPercentile() {
            if (totalUsers <= 1) return 100.0;
            return ((double)(totalUsers - rank) / (totalUsers - 1)) * 100;
        }
    }
}
