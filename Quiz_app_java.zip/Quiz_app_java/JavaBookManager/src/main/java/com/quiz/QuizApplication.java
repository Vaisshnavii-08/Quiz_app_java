package com.quiz;

import com.quiz.database.DatabaseManager;
import com.quiz.view.LoginView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Main application class for the Online Quiz Application
 */
public class QuizApplication extends Application {
    
    private static Stage primaryStage;
    
    @Override
    public void start(Stage stage) {
        primaryStage = stage;
        
        // Initialize database
        DatabaseManager.initializeDatabase();
        
        // Set up the primary stage
        primaryStage.setTitle("Online Quiz Application");
        primaryStage.setMinWidth(800);
        primaryStage.setMinHeight(600);
        
        // Show login view
        showLoginView();
        
        primaryStage.show();
    }
    
    public static void showLoginView() {
        LoginView loginView = new LoginView();
        Scene scene = new Scene(loginView.getView(), 800, 600);
        scene.getStylesheets().add(QuizApplication.class.getResource("/styles.css").toExternalForm());
        primaryStage.setScene(scene);
    }
    
    public static Stage getPrimaryStage() {
        return primaryStage;
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
