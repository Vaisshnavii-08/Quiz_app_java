package com.quiz.view;

import com.quiz.QuizApplication;
import com.quiz.controller.LoginController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Login and registration view
 */
public class LoginView {
    private VBox mainContainer;
    private LoginController controller;
    private TabPane tabPane;
    
    public LoginView() {
        this.controller = new LoginController(QuizApplication.getPrimaryStage());
        createView();
    }
    
    private void createView() {
        mainContainer = new VBox(20);
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setPadding(new Insets(50));
        mainContainer.getStyleClass().add("main-container");
        
        // Title
        Label titleLabel = new Label("Online Quiz Application");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        titleLabel.getStyleClass().add("title-label");
        
        // Create tabs for login and registration
        tabPane = new TabPane();
        tabPane.setMaxWidth(400);
        
        // Login tab
        Tab loginTab = new Tab("Login");
        loginTab.setClosable(false);
        loginTab.setContent(createLoginForm());
        
        // Registration tab
        Tab registerTab = new Tab("Register");
        registerTab.setClosable(false);
        registerTab.setContent(createRegistrationForm());
        
        tabPane.getTabs().addAll(loginTab, registerTab);
        
        mainContainer.getChildren().addAll(titleLabel, tabPane);
    }
    
    private VBox createLoginForm() {
        VBox loginForm = new VBox(15);
        loginForm.setAlignment(Pos.CENTER);
        loginForm.setPadding(new Insets(30));
        
        // Username field
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter username");
        usernameField.setPrefWidth(300);
        
        // Password field
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.setPrefWidth(300);
        
        // Login button
        Button loginButton = new Button("Login");
        loginButton.setPrefWidth(120);
        loginButton.getStyleClass().add("primary-button");
        
        // Handle login
        loginButton.setOnAction(e -> {
            controller.login(usernameField.getText(), passwordField.getText());
        });
        
        // Handle Enter key in password field
        passwordField.setOnAction(e -> loginButton.fire());
        
        loginForm.getChildren().addAll(
            usernameLabel, usernameField,
            passwordLabel, passwordField,
            loginButton
        );
        
        return loginForm;
    }
    
    private VBox createRegistrationForm() {
        VBox registerForm = new VBox(15);
        registerForm.setAlignment(Pos.CENTER);
        registerForm.setPadding(new Insets(30));
        
        // Username field
        Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter username (min 3 characters)");
        usernameField.setPrefWidth(300);
        
        // Password field
        Label passwordLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password (min 6 characters)");
        passwordField.setPrefWidth(300);
        
        // Confirm password field
        Label confirmPasswordLabel = new Label("Confirm Password:");
        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm password");
        confirmPasswordField.setPrefWidth(300);
        
        // Role selection
        Label roleLabel = new Label("Account Type:");
        RadioButton userRadio = new RadioButton("Regular User");
        RadioButton adminRadio = new RadioButton("Administrator");
        
        ToggleGroup roleGroup = new ToggleGroup();
        userRadio.setToggleGroup(roleGroup);
        adminRadio.setToggleGroup(roleGroup);
        userRadio.setSelected(true); // Default to user
        
        HBox roleBox = new HBox(20);
        roleBox.setAlignment(Pos.CENTER);
        roleBox.getChildren().addAll(userRadio, adminRadio);
        
        // Register button
        Button registerButton = new Button("Register");
        registerButton.setPrefWidth(120);
        registerButton.getStyleClass().add("primary-button");
        
        // Handle registration
        registerButton.setOnAction(e -> {
            boolean isAdmin = adminRadio.isSelected();
            if (controller.register(
                usernameField.getText(),
                passwordField.getText(),
                confirmPasswordField.getText(),
                isAdmin
            )) {
                // Clear form and switch to login tab
                usernameField.clear();
                passwordField.clear();
                confirmPasswordField.clear();
                userRadio.setSelected(true);
                tabPane.getSelectionModel().select(0); // Switch to login tab
            }
        });
        
        registerForm.getChildren().addAll(
            usernameLabel, usernameField,
            passwordLabel, passwordField,
            confirmPasswordLabel, confirmPasswordField,
            roleLabel, roleBox,
            registerButton
        );
        
        return registerForm;
    }
    
    public VBox getView() {
        return mainContainer;
    }
}
