package com.quiz.controller;

import com.quiz.dao.UserDAO;
import com.quiz.model.User;
import com.quiz.util.AlertUtil;
import com.quiz.util.PasswordUtil;
import com.quiz.view.AdminView;
import com.quiz.view.UserView;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Controller for handling login and registration logic
 */
public class LoginController {
    private UserDAO userDAO;
    private Stage primaryStage;
    
    public LoginController(Stage primaryStage) {
        this.userDAO = new UserDAO();
        this.primaryStage = primaryStage;
    }
    
    /**
     * Handle user login
     */
    public boolean login(String username, String password) {
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            AlertUtil.showError("Login Error", "Please enter both username and password.");
            return false;
        }
        
        User user = userDAO.findByUsername(username.trim());
        
        if (user == null) {
            AlertUtil.showError("Login Error", "User not found.");
            return false;
        }
        
        if (!PasswordUtil.verifyPassword(password, user.getPasswordHash())) {
            AlertUtil.showError("Login Error", "Invalid password.");
            return false;
        }
        
        // Login successful, show appropriate dashboard
        if (user.isAdmin()) {
            showAdminDashboard(user);
        } else {
            showUserDashboard(user);
        }
        
        return true;
    }
    
    /**
     * Handle user registration
     */
    public boolean register(String username, String password, String confirmPassword, boolean isAdmin) {
        // Validate input
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            AlertUtil.showError("Registration Error", "Please fill in all fields.");
            return false;
        }
        
        if (username.trim().length() < 3) {
            AlertUtil.showError("Registration Error", "Username must be at least 3 characters long.");
            return false;
        }
        
        if (password.length() < 6) {
            AlertUtil.showError("Registration Error", "Password must be at least 6 characters long.");
            return false;
        }
        
        if (!password.equals(confirmPassword)) {
            AlertUtil.showError("Registration Error", "Passwords do not match.");
            return false;
        }
        
        // Check if username already exists
        if (userDAO.usernameExists(username.trim())) {
            AlertUtil.showError("Registration Error", "Username already exists.");
            return false;
        }
        
        // Create new user
        String hashedPassword = PasswordUtil.hashPassword(password);
        String role = isAdmin ? "admin" : "user";
        
        User newUser = new User(username.trim(), hashedPassword, "", role);
        
        if (userDAO.createUser(newUser)) {
            AlertUtil.showSuccess("Registration Successful", "User registered successfully!");
            return true;
        } else {
            AlertUtil.showError("Registration Error", "Failed to create user. Please try again.");
            return false;
        }
    }
    
    /**
     * Show admin dashboard
     */
    private void showAdminDashboard(User user) {
        AdminView adminView = new AdminView(user);
        Scene scene = new Scene(adminView.getView(), 1000, 700);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("Quiz Application - Admin Dashboard");
    }
    
    /**
     * Show user dashboard
     */
    private void showUserDashboard(User user) {
        UserView userView = new UserView(user);
        Scene scene = new Scene(userView.getView(), 1000, 700);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.setTitle("Quiz Application - User Dashboard");
    }
}
